package com.example.android.quizapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    int numOfQuestions = 0;
    int correctAnswers = 0;

    int answer1;
    boolean answer2 = false;
    boolean answer3 = false;
    int answer4;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void setAnswer2(View view) {
        boolean question2Checked = ((RadioButton) view).isChecked();

        switch(view.getId()) {
            case R.id.question_2_answer_1:
                if(question2Checked)
                    answer2 = false;
                    break;
            case R.id.question_2_answer_2:
                if(question2Checked)
                    answer2 = false;
                    break;
            case R.id.question_2_answer_3:
                if(question2Checked)
                    answer2 = true;
                    break;
            case R.id.question_2_answer_4:
                if(question2Checked)
                    answer2 = false;
                    break;
        }
    }

    public void setAnswer3(View view) {
        CheckBox answer3_1 = (CheckBox)findViewById(R.id.question_3_answer_1);
        CheckBox answer3_2 = (CheckBox)findViewById(R.id.question_3_answer_2);
        CheckBox answer3_3 = (CheckBox)findViewById(R.id.question_3_answer_3);
        CheckBox answer3_4 = (CheckBox)findViewById(R.id.question_3_answer_4);

        switch(view.getId()) {
            case R.id.question_3_answer_1:
                if(answer3_1.isChecked()&&answer3_2.isChecked()&&
                        !answer3_3.isChecked()&&!answer3_4.isChecked())
                    answer3 = true;
                else answer3 = false;
                break;
            case R.id.question_3_answer_2:
                if(answer3_1.isChecked()&&answer3_2.isChecked()&&
                        !answer3_3.isChecked()&&!answer3_4.isChecked())
                    answer3 = true;
                else answer3 = false;
                break;
            case R.id.question_3_answer_3:
                answer3 = false;
                break;
            case R.id.question_3_answer_4:
                answer3 = false;
                break;
        }
    }

    public void submitAnswers(View view) {
        // Question 1
        numOfQuestions++;
        EditText question1Answer = (EditText) findViewById(R.id.question_1_answer);
        String answer1String = question1Answer.getText().toString();
        if(!answer1String.matches("")) {
            answer1 = Integer.parseInt(question1Answer.getText().toString());
        }
        else {answer1 = 0;}

        // Question 2
        numOfQuestions++;

        // Question 3
        numOfQuestions++;

        // QUESTION 4
        numOfQuestions++;
        EditText question4Answer = (EditText) findViewById(R.id.question_4_answer);
        String answer4String = question1Answer.getText().toString();
        if(!answer4String.matches("")) {
            answer4 = Integer.parseInt(question4Answer.getText().toString());
        }
        else {answer4 = 0;}

        checkAnswers();
    }

    private void checkAnswers() {
        // Question 1
        if(answer1==4*4) {correctAnswers++;}

        // Question 2
        if(answer2) {correctAnswers++;}

        // Question 3
        if(answer3) {correctAnswers++;}

        // Question 4
        if(answer4==100+100*9) {correctAnswers++;}

        Toast.makeText(this, "You answered " + correctAnswers + " out of " + numOfQuestions
                + " questions correct!", Toast.LENGTH_LONG).show();

        resetVariables();
    }

    private void resetVariables() {
        numOfQuestions = 0;
        correctAnswers = 0;
    }
}
